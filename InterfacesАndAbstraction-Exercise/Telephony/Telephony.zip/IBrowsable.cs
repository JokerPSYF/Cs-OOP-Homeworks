﻿namespace Telephony
{
    public interface IBrowsable
    {
        public string Browse(string site);
    }
}