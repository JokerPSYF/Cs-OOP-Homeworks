﻿namespace BirthdayCelebrations
{
    public interface IBirthdable
    {
        public string BirthDate { get; set; }
    }
}